package ict.basics;

public interface IDeepCopy {
	public IDeepCopy deepCopy();
}
