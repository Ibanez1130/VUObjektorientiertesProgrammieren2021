package rbs;

public enum BookingState {
	OPEN,
	CLOSED,
	PAID,
	CANCELLED;
}
