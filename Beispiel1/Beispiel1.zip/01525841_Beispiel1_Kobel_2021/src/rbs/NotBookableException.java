package rbs;

public class NotBookableException extends Exception {
	public static final long serialVersionUID = 21;
}
