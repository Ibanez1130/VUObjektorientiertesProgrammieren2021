package rbs.record;

public interface IRecord {
	public long getId();
}
