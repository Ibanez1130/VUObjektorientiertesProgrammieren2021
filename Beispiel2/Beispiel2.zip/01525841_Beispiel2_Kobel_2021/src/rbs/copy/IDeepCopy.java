package rbs.copy;

public interface IDeepCopy {
	public IDeepCopy deepCopy();
}
