package util.searchable;

public interface ISearchFilter {
	public boolean searchFilterFunction(Object originalObject, Object compareObject);
}
