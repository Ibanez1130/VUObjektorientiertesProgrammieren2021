package application;

public class ConsoleMenue {

	public static void main(String[] args) {
		// TODO: implement your console based menue here
		
		System.out.println("Application running...");
	}
}
